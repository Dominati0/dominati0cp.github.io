# Debuiger Arena

Personal competitive programming profile (Codeforces, AtCoder, LeetCode, TLX).

## Put it online with GitHub Pages
1. Create a new public repository on GitHub, e.g. `debuiger-arena`
   (or name it `<your-github-username>.github.io` to get the short URL).
2. Click **Add file → Upload files** and drop in `index.html`, `avatar.jpg`, `avatar-night.jpg`, `mountain.jpg`, `night.jpg`, `theme-alpine.mp3` and `theme-night.mp3`. Commit.
3. Go to **Settings → Pages**, set **Source: Deploy from a branch**, branch `main`, folder `/ (root)`, Save.
4. After about a minute the site is live at `https://<username>.github.io/debuiger-arena/`.

## Editing
Open `index.html` and change the `CONFIG` block at the top of the script:
- `handles` – your usernames.
- `stats` – fallback numbers. TLX has no public API, so put your TLX numbers here.
- `lyrics` – paste the timed lyrics you made with Tap-sync → Copy, so every visitor sees them.

Codeforces and AtCoder (via AtCoder Problems) load live on every visit.
LeetCode goes through a community API (alfa-leetcode-api); if it's down, the fallback numbers are shown.
